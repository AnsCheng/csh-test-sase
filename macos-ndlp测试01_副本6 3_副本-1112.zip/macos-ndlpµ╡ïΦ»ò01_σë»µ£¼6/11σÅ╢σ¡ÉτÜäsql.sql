SELECT * FROM test where tel = "15399482324";
SELECT * FROM test where name = "leaves-aino";
SELECT * FROM test where email = "zhaoyajuan2324@dingtalk.com";
SELECT * FROM test where gender = "女";
SELECT * FROM test where email = "619765206@qq.com";

select a.`id`, a.`devOnlyId`, a.`ip`, a.`mac`, a.`hostname`, a.`reportTime`,a.`channelType`, a.`processName`,a.`filePath`,a.`fileSize`,a.`remoteAddress`,a.`uploadFileGuid`,a.`mailFrom`,a.`mailTo`,a.`subject`, ifnull(a.`body`, \"\") as body, a.`remoteHost`, ifnull(b.`fileId`, \"\") as fileId, ifnull(c.`fdfsPath`, \"\") as fdfsPath from `sase_edlp_protectionaudit_log` as a left join `sase_edlp_file_upload_log` as b on a.`uploadFileGuid` = b.`uploadFileGuid` left join `sase_edlp_file_upload` as c on b.`fileId`= c.`fileId` where a.`status`= ? for update"

