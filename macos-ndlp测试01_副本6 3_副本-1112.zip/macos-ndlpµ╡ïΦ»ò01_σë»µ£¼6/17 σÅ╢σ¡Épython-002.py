﻿#encoding=utf-8

#计算key-value是否是唯一的匹配项：
key_vaule={}
new_key={}
key1=""
vaule1=""
a=[{"abab":"12123"},{"abab":"1212"},{"asd":"123"},{"abad":"1213"}]
for i in a:
    for key,vaule in i.items():
        if len(key)==len(vaule):
            for h in range(len(key)):
                for g in range(len(vaule)):
                    if h==g:
                        if key[h] not in key1:
                            key1+=key[h]
                            vaule1+=vaule[g]
                            new_key[key[h]]=vaule[g]
                            break
                        elif key[h] in key1:
                            if new_key[key[h]] == vaule[g]:
                                key1 += key[h]
                                vaule1 += vaule[g]
                            else:
                                continue
            key_vaule[key1] = vaule1
            key1=""
            vaule1=""
        else:
            break
print(key_vaule)


a="cxxxaxbcxxyabc"
def m(a,b):
    count_b=0
    x=len(b)
    m=[]
    for i in range(len(a)):
        if i not in m:
            if a[i:i+x]==b:
                count_b += 1
                m.append(i+1)
    return count_b
print(m(a,b="xx"))

