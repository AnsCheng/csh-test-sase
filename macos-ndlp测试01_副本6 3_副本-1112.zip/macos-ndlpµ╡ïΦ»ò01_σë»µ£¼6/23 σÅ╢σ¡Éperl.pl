#!/usr/bin/perl
 
for( ; ; )
{
   printf "循环会无限执行。\n";
}